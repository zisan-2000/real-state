"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ChevronDown } from "lucide-react"
import { motion } from "framer-motion"
import { getDirection } from "@/lib/utils"

interface HeroSectionProps {
  dictionary: any
  isRtl: boolean
}

export default function HeroSection({ dictionary, isRtl }: HeroSectionProps) {
  const [scrollY, setScrollY] = useState(0)
  const heroRef = useRef<HTMLDivElement>(null)
  const dir = getDirection(isRtl ? "ar" : "en")

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToNextSection = () => {
    if (heroRef.current) {
      const nextSection = heroRef.current.nextElementSibling
      if (nextSection) {
        nextSection.scrollIntoView({ behavior: "smooth" })
      }
    }
  }

  const parallaxStyle = {
    transform: `translateY(${scrollY * 0.4}px)`,
  }

  return (
    <section ref={heroRef} className="relative flex min-h-screen items-center justify-center overflow-hidden" dir={dir}>
      {/* Background Image with Parallax */}
      <div className="absolute inset-0 z-0" style={parallaxStyle}>
        <Image
          src="/placeholder.svg?height=1080&width=1920"
          alt="Saudi Real Estate"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 to-black/30" />
      </div>

      {/* Content */}
      <div className="container relative z-10 mx-auto px-4 text-center text-white">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="mb-6 bg-gradient-to-r from-amber-200 to-yellow-500 bg-clip-text text-4xl font-bold leading-tight text-transparent sm:text-5xl md:text-6xl">
            {dictionary.title}
          </h1>

          <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="rounded-lg bg-black/30 p-4 backdrop-blur-sm">
              <h3 className="text-xl font-semibold text-amber-300">{dictionary.vision}</h3>
              <p className="mt-2 text-sm text-gray-200">
                {isRtl
                  ? "سجل رؤيتك العقارية وكن جزءًا من مستقبل التطوير العقاري في المملكة"
                  : "Register your real estate vision and be part of the future of development in the Kingdom"}
              </p>
            </div>
            <div className="rounded-lg bg-black/30 p-4 backdrop-blur-sm">
              <h3 className="text-xl font-semibold text-amber-300">{dictionary.investment}</h3>
              <p className="mt-2 text-sm text-gray-200">
                {isRtl
                  ? "اكتشف فرص استثمارية متميزة في مختلف مناطق المملكة العربية السعودية"
                  : "Discover premium investment opportunities across various regions of Saudi Arabia"}
              </p>
            </div>
          </div>

          <div className="mt-8 flex flex-col items-center justify-center space-y-4 sm:flex-row sm:space-x-4 sm:space-y-0 rtl:space-x-reverse">
            <Button
              size="lg"
              className="bg-gradient-to-r from-amber-500 to-yellow-600 text-white hover:from-amber-600 hover:to-yellow-700"
            >
              {dictionary.explore}
            </Button>
            <Button variant="outline" size="lg" className="border-white bg-transparent text-white hover:bg-white/10">
              {dictionary.contact}
            </Button>
          </div>
        </motion.div>

        {/* Scroll Down Indicator */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 cursor-pointer"
          onClick={scrollToNextSection}
        >
          <div className="flex flex-col items-center">
            <span className="mb-2 text-sm font-light">{dictionary.scrollDown}</span>
            <motion.div animate={{ y: [0, 10, 0] }} transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}>
              <ChevronDown className="h-6 w-6" />
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
