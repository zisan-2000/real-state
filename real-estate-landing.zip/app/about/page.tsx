import AboutPage from "@/pages/about"

export default function About() {
  return <AboutPage />
}
