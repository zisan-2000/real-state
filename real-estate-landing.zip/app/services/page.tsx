import { getDictionary } from "@/dictionaries"
import ServicesPage from "@/pages/services"
import { i18n } from "@/i18n-config"

export default async function Services() {
  const dictionary = await getDictionary(i18n.defaultLocale)
  return <ServicesPage />
}
