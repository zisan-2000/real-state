"use client"

import React from "react"

import { useRef } from "react"
import { motion, useInView } from "framer-motion"
import { Building, Map, Users, BarChart3 } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { getDirection } from "@/lib/utils"

interface ServicesSectionProps {
  dictionary: any
  isRtl: boolean
}

export default function ServicesSection({ dictionary, isRtl }: ServicesSectionProps) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, threshold: 0.1 })
  const dir = getDirection(isRtl ? "ar" : "en")

  const serviceIcons = [
    { icon: Building, color: "text-amber-500" },
    { icon: Map, color: "text-emerald-500" },
    { icon: Users, color: "text-blue-500" },
    { icon: BarChart3, color: "text-purple-500" },
  ]

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  }

  return (
    <section ref={ref} className="bg-background py-16 md:py-24" dir={dir}>
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="mb-2 text-3xl font-bold md:text-4xl">{dictionary.title}</h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">{dictionary.subtitle}</p>
        </div>

        <motion.div
          variants={container}
          initial="hidden"
          animate={isInView ? "show" : "hidden"}
          className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4"
        >
          {dictionary.items.map((service: any, index: number) => (
            <motion.div key={index} variants={item}>
              <Card
                className="h-full border-t-4 transition-all hover:shadow-md dark:hover:shadow-primary/5"
                style={{
                  borderTopColor: `var(--${index === 0 ? "amber" : index === 1 ? "emerald" : index === 2 ? "blue" : "purple"}-500)`,
                }}
              >
                <CardContent className="flex h-full flex-col p-6">
                  <div className="mb-4">
                    {React.createElement(serviceIcons[index].icon, {
                      className: `h-10 w-10 ${serviceIcons[index].color}`,
                    })}
                  </div>
                  <h3 className="mb-2 text-xl font-semibold">{service.title}</h3>
                  <p className="mt-auto text-muted-foreground">{service.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
