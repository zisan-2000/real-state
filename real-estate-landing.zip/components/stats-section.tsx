"use client"

import { useEffect, useRef } from "react"
import { motion, useAnimation, useInView } from "framer-motion"
import { getDirection } from "@/lib/utils"

interface StatsProps {
  dictionary: any
  isRtl: boolean
}

export default function StatsSection({ dictionary, isRtl }: StatsProps) {
  const controls = useAnimation()
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, threshold: 0.2 })
  const dir = getDirection(isRtl ? "ar" : "en")

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [controls, isInView])

  const stats = [
    {
      title: dictionary.landArea,
      value: dictionary.landAreaValue,
      percentage: 85,
    },
    {
      title: dictionary.offers,
      value: dictionary.offersValue,
      percentage: 75,
    },
    {
      title: dictionary.developers,
      value: dictionary.developersValue,
      percentage: 65,
    },
  ]

  return (
    <section ref={ref} className="bg-background py-16 md:py-24" dir={dir}>
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial="hidden"
              animate={controls}
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: {
                  opacity: 1,
                  y: 0,
                  transition: { duration: 0.6, delay: index * 0.2 },
                },
              }}
              className="flex flex-col items-center justify-center text-center"
            >
              <div className="relative mb-4 h-40 w-40">
                <svg className="h-full w-full" viewBox="0 0 100 100">
                  <circle className="stroke-muted" cx="50" cy="50" r="40" strokeWidth="8" fill="none" />
                  <motion.circle
                    className="stroke-primary"
                    cx="50"
                    cy="50"
                    r="40"
                    strokeWidth="8"
                    fill="none"
                    strokeLinecap="round"
                    initial={{ pathLength: 0 }}
                    animate={controls}
                    variants={{
                      hidden: { pathLength: 0 },
                      visible: {
                        pathLength: stat.percentage / 100,
                        transition: {
                          pathLength: { duration: 1.5, delay: index * 0.2 },
                        },
                      },
                    }}
                    style={{
                      transformOrigin: "center",
                      transform: "rotate(-90deg)",
                    }}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-2xl font-bold text-primary">{stat.value}</span>
                </div>
              </div>
              <h3 className="text-xl font-semibold">{stat.title}</h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
