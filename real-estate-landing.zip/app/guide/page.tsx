import UserGuidePage from "@/pages/guide"

export default function Guide() {
  return <UserGuidePage />
}
