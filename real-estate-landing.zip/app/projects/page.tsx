import ProjectsPage from "@/pages/projects"

export default function Projects() {
  return <ProjectsPage />
}
