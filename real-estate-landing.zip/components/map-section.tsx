"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { getDirection } from "@/lib/utils"

interface MapSectionProps {
  dictionary: any
  isRtl: boolean
}

export default function MapSection({ dictionary, isRtl }: MapSectionProps) {
  const [activeRegion, setActiveRegion] = useState<string | null>("riyadh")
  const dir = getDirection(isRtl ? "ar" : "en")

  // Safely access regions or provide fallback data
  const regions = dictionary?.map?.regions || {
    riyadh: {
      name: isRtl ? "الرياض" : "Riyadh",
      projects: isRtl ? "125 مشروع" : "125 Projects",
      area: isRtl ? "450,000 متر مربع" : "450,000 sqm",
    },
    makkah: {
      name: isRtl ? "مكة المكرمة" : "Makkah",
      projects: isRtl ? "98 مشروع" : "98 Projects",
      area: isRtl ? "320,000 متر مربع" : "320,000 sqm",
    },
    eastern: {
      name: isRtl ? "المنطقة الشرقية" : "Eastern Province",
      projects: isRtl ? "87 مشروع" : "87 Projects",
      area: isRtl ? "280,000 متر مربع" : "280,000 sqm",
    },
    madinah: {
      name: isRtl ? "المدينة المنورة" : "Madinah",
      projects: isRtl ? "45 مشروع" : "45 Projects",
      area: isRtl ? "150,000 متر مربع" : "150,000 sqm",
    },
  }

  // Safely access title and subtitle or provide fallback
  const title = dictionary?.map?.title || (isRtl ? "النشاط العقاري حسب المنطقة" : "Real Estate Activity by Region")
  const subtitle =
    dictionary?.map?.subtitle ||
    (isRtl
      ? "استكشف فرص الاستثمار في جميع أنحاء المملكة العربية السعودية"
      : "Explore investment opportunities across Saudi Arabia")

  const handleRegionHover = (region: string) => {
    setActiveRegion(region)
  }

  return (
    <section className="bg-muted/30 py-16 md:py-24" dir={dir}>
      <div className="container mx-auto px-4">
        <div className="mb-10 text-center">
          <h2 className="mb-2 text-3xl font-bold md:text-4xl">{title}</h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">{subtitle}</p>
        </div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
          {/* SVG Map of Saudi Arabia */}
          <div className="flex items-center justify-center">
            <svg
              width="500"
              height="400"
              viewBox="0 0 500 400"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="max-w-full"
            >
              {/* Simplified Saudi Arabia map */}
              <motion.path
                d="M100,200 L150,150 L250,100 L350,150 L400,200 L350,250 L250,300 L150,250 Z"
                fill="currentColor"
                className="text-muted/30"
                stroke="currentColor"
                strokeWidth="2"
              />

              {/* Riyadh Region */}
              <motion.circle
                cx="250"
                cy="200"
                r="25"
                className={`cursor-pointer ${activeRegion === "riyadh" ? "fill-primary/70" : "fill-primary/30"}`}
                whileHover={{ scale: 1.1 }}
                onClick={() => handleRegionHover("riyadh")}
              />

              {/* Makkah Region */}
              <motion.circle
                cx="180"
                cy="250"
                r="20"
                className={`cursor-pointer ${activeRegion === "makkah" ? "fill-primary/70" : "fill-primary/30"}`}
                whileHover={{ scale: 1.1 }}
                onClick={() => handleRegionHover("makkah")}
              />

              {/* Eastern Province */}
              <motion.circle
                cx="320"
                cy="180"
                r="22"
                className={`cursor-pointer ${activeRegion === "eastern" ? "fill-primary/70" : "fill-primary/30"}`}
                whileHover={{ scale: 1.1 }}
                onClick={() => handleRegionHover("eastern")}
              />

              {/* Madinah Region */}
              <motion.circle
                cx="200"
                cy="170"
                r="18"
                className={`cursor-pointer ${activeRegion === "madinah" ? "fill-primary/70" : "fill-primary/30"}`}
                whileHover={{ scale: 1.1 }}
                onClick={() => handleRegionHover("madinah")}
              />

              {/* Region Labels */}
              <text x="250" y="200" textAnchor="middle" className="fill-current text-xs font-medium">
                {isRtl ? "الرياض" : "Riyadh"}
              </text>
              <text x="180" y="250" textAnchor="middle" className="fill-current text-xs font-medium">
                {isRtl ? "مكة" : "Makkah"}
              </text>
              <text x="320" y="180" textAnchor="middle" className="fill-current text-xs font-medium">
                {isRtl ? "الشرقية" : "Eastern"}
              </text>
              <text x="200" y="170" textAnchor="middle" className="fill-current text-xs font-medium">
                {isRtl ? "المدينة" : "Madinah"}
              </text>
            </svg>
          </div>

          {/* Region Information */}
          <div className="flex items-center justify-center">
            {activeRegion && regions[activeRegion] && (
              <motion.div
                initial={{ opacity: 0, x: isRtl ? -20 : 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3 }}
                className="w-full"
              >
                <Card className="overflow-hidden border-primary/20 bg-card/50 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <h3 className="mb-4 text-2xl font-bold text-primary">{regions[activeRegion].name}</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="rounded-lg bg-background/50 p-4">
                        <p className="text-sm font-medium text-muted-foreground">{isRtl ? "المشاريع" : "Projects"}</p>
                        <p className="mt-1 text-xl font-semibold">{regions[activeRegion].projects}</p>
                      </div>
                      <div className="rounded-lg bg-background/50 p-4">
                        <p className="text-sm font-medium text-muted-foreground">{isRtl ? "المساحة" : "Area"}</p>
                        <p className="mt-1 text-xl font-semibold">{regions[activeRegion].area}</p>
                      </div>
                    </div>
                    <div className="mt-4 rounded-lg bg-background/50 p-4">
                      <p className="text-sm font-medium text-muted-foreground">
                        {isRtl ? "الفرص الاستثمارية" : "Investment Opportunities"}
                      </p>
                      <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-muted">
                        <motion.div
                          className="h-full bg-primary"
                          initial={{ width: 0 }}
                          animate={{
                            width:
                              activeRegion === "riyadh"
                                ? "80%"
                                : activeRegion === "makkah"
                                  ? "70%"
                                  : activeRegion === "eastern"
                                    ? "65%"
                                    : "50%",
                          }}
                          transition={{ duration: 0.5 }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
